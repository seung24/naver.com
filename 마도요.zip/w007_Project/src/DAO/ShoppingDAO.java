package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import DTO.ShoppingVO;
import util.DBManager;

public class ShoppingDAO {
	private ShoppingDAO() {
	}

	private static ShoppingDAO instance = new ShoppingDAO();

	public static ShoppingDAO getInstance() {
		return instance;
	}

	public int allCount() {
		String sql = "select count(*) from shopping";
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				return rs.getInt(1);
			}

		} catch (Exception e) {
			System.out.println("1");
			e.printStackTrace();
		} finally {
			DBManager.close(conn, pstmt, rs);
		}
		return 0;

	}

	public List<ShoppingVO> limitSelect(int start, int end) {
		/**
		 * select * from ( select * from product ) where rownum >= 2 and rownum <= 4;
		 * 
		 * 
		 * 
		 * select t.* from(select sub.name , rownum as rnum from (select * from product
		 * order by day DESC) sub) t where rnum between 2 and 4;
		 * 
		 * SQL> desc product; 이름 널? 유형 -----------------------------------------
		 * -------- ----------------
		 * 
		 * CODE NUMBER(2) NAME VARCHAR2(100) PRICE NUMBER(10) PICTUREURL VARCHAR2(100)
		 * DESCRIPTION VARCHAR2(100)
		 * 
		 * SQL> alter table product add day varchar2(50);
		 * 
		 * 테이블이 변경되었습니다.
		 * 
		 * 
		 */
		String sql = "select t.* from (select sub.*, rownum as rnum from (select * from shopping order by day DESC) sub) t where rnum between ? and ?";
		List<ShoppingVO> list = new ArrayList<ShoppingVO>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, start);
			pstmt.setInt(2, end);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				ShoppingVO sdto = new ShoppingVO();
				sdto.setCode(rs.getInt("code"));
				sdto.setName(rs.getString("name"));
				sdto.setPrice(rs.getInt("price"));
				sdto.setPictureUrl(rs.getString("pictureUrl"));
				sdto.setDescription(rs.getString("description"));
				list.add(sdto);
			} // while臾� �걹
		} catch (Exception e) {
			System.out.println("2");
			e.printStackTrace();
		} finally {
			DBManager.close(conn, pstmt, rs);
		}
		return list;
	}

	public List<ShoppingVO> selectAllShopping() {
		// 최근 등록한 상품 먼저 출력하기
		String sql = "select * from shopping order by code desc";
		List<ShoppingVO> list = new ArrayList<ShoppingVO>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) { // 이동은 행(로우) 단위로
				ShoppingVO sdto = new ShoppingVO();
				sdto.setCode(rs.getInt("code"));
				sdto.setName(rs.getString("name"));
				sdto.setPrice(rs.getInt("price"));
				sdto.setPictureUrl(rs.getString("pictureUrl"));
				sdto.setDescription(rs.getString("description"));
				list.add(sdto);
			} // while문 끝
		} catch (Exception e) {
			System.out.println("3");
			e.printStackTrace();
		} finally {
			DBManager.close(conn, pstmt, rs);
		}
		return list;
	}// selectAllProducts() {

	public void insertShopping(ShoppingVO sdto) {
		String sql = "insert into shopping values(shopping_seq.nextval, ?, ?, ?, ?, TO_CHAR(SYSDATE, 'YYYY.MM.DD HH24:MI:SS'))";
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, sdto.getName());
			pstmt.setInt(2, sdto.getPrice());
			pstmt.setString(3, sdto.getPictureUrl());
			pstmt.setString(4, sdto.getDescription());
			pstmt.executeUpdate(); // 실행
		} catch (Exception e) {
			System.out.println("4");
			e.printStackTrace();
		} finally {
			DBManager.close(conn, pstmt);
		}
	}

	public ShoppingVO selectShoppingByCode(String code) {
		String sql = "select * from shopping where code=?";
		ShoppingVO sdto = null;
		try {
			Connection conn = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			try {
				conn = DBManager.getConnection();
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, code);
				rs = pstmt.executeQuery();
				if (rs.next()) {
					sdto = new ShoppingVO();
					sdto.setCode(rs.getInt("code"));
					sdto.setName(rs.getString("name"));
					sdto.setPrice(rs.getInt("price"));
					sdto.setPictureUrl(rs.getString("pictureUrl"));
					sdto.setDescription(rs.getString("description"));
				}
			} catch (Exception e) {
				System.out.println("5");
				e.printStackTrace();
			} finally {
				DBManager.close(conn, pstmt, rs);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return sdto;
	}

	public void updateShopping(ShoppingVO sdto) {
		String sql = "update shopping set name=?, price=?, pictureurl=?, description=? where code=?";
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, sdto.getName());
			pstmt.setInt(2, sdto.getPrice());
			pstmt.setString(3, sdto.getPictureUrl());
			pstmt.setString(4, sdto.getDescription());
			pstmt.setInt(5, sdto.getCode());
			pstmt.executeUpdate();// 쿼리문 실행한다.
		} catch (Exception e) {
			System.out.println("6");
			e.printStackTrace();
		} finally {
			DBManager.close(conn, pstmt);
		}
	}

	public void deleteShopping(String code) {
		String sql = "delete shopping where code=?";
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, code);
			pstmt.executeUpdate();// 쿼리문 실행
		} catch (Exception e) {
			System.out.println("7");
			e.printStackTrace();
		} finally {
			DBManager.close(conn, pstmt);
		}
	}

}
