package controller_S;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

import DAO.ShoppingDAO;
import DTO.ShoppingVO;

/**
 * Servlet implementation class ShoppingWriteServlet
 */
@WebServlet("/ShoppingWrite.do")
public class ShoppingWriteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ShoppingWriteServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println("get");
		RequestDispatcher dispatcher = request.getRequestDispatcher("shopping/ShoppingWrite.jsp");
		dispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		ServletContext context = getServletContext();
		String path = context.getRealPath("upload");
		System.out.println(path + " �� �����Ѵ�.");
		String encType = "UTF-8";
		int sizeLimit = 20 * 1024 * 1024;
		MultipartRequest multi = new MultipartRequest(request, path, sizeLimit, encType, new DefaultFileRenamePolicy());
		String pictureUrl = multi.getFilesystemName("pictureUrl");
		String name = multi.getParameter("name");
		int price = Integer.parseInt(multi.getParameter("price"));
		String description = multi.getParameter("description");
		if (pictureUrl == null) {
			System.out.println("���ε� ����");
		} else {
//			System.out.println(pictureUrl + " ok");
		}
		ShoppingVO sDTO = new ShoppingVO();
		sDTO.setName(name);
		sDTO.setPrice(price);
		sDTO.setDescription(description);
		sDTO.setPictureUrl(pictureUrl);
		ShoppingDAO sDAO = ShoppingDAO.getInstance();
		sDAO.insertShopping(sDTO);
		response.sendRedirect("ShoppingList.do");
	}

}
