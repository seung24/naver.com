package Controller_M;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import DAO.MembersDAO;
import DTO.MembersDTO;

/**
 * Servlet implementation class MembersUpdateServlet
 */
@WebServlet("/MembersUpdateServlet")
public class MembersUpdateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet() 
     */
    public MembersUpdateServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String id = request.getParameter("id");
		MembersDAO mDAO = MembersDAO.getInstance();
		MembersDTO mDTO = mDAO.selectMembersByID(id);
		request.setAttribute("memberList", mDTO);
		RequestDispatcher dispatcher = request.getRequestDispatcher("shopping/ShoppingUpdate.jsp");
		dispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String id = request.getParameter("id");
		String pwd = request.getParameter("pwd");
		String name = request.getParameter("name");
		String phone = request.getParameter("phone");
		String addr = request.getParameter("addr");
		
		MembersDTO mDTO = new MembersDTO();
		mDTO.setId(id);
		mDTO.setPwd(pwd);
		mDTO.setName(name);
		mDTO.setPhone(phone);
		mDTO.setAddr(addr);
		MembersDAO mDAO = MembersDAO.getInstance();
		mDAO.updateMembers(mDTO);
		response.sendRedirect("넣어야 됨");
	}
}
