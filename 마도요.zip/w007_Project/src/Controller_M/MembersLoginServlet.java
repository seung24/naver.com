package Controller_M;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import DAO.MembersDAO;
import DTO.MembersDTO;

/**
 * Servlet implementation class MembersLoginServlet
 */
@WebServlet("/MembersLoginServlet")
public class MembersLoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public MembersLoginServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String url = "shop.jsp"; // 로그인 전의 Main화면
		RequestDispatcher dispatcher = request.getRequestDispatcher(url);
		dispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String pwd = request.getParameter("ipwd");
		String id = request.getParameter("iid");
		MembersDAO mDAO = MembersDAO.getInstance();
		MembersDTO mDTO = new MembersDTO();
		mDTO.setId(id);
		mDTO.setPwd(pwd);
		mDTO = mDAO.accountLogin(mDTO);	
		
		//로그인
		if(mDTO!=null) {
			System.out.println("로그인 성공");
			request.setAttribute("id", id);
			RequestDispatcher dispatcher = request.getRequestDispatcher("shopM.jsp"); // 로그인 성공하면 새로운 Main화면
			dispatcher.forward(request, response);
		//아이디 불일치할 때
		}else {
			System.out.println("로그인 실패"); // 로그인이 실패하면 다시 로그인 화면으로 
			String chks = "x";
			request.setAttribute("chkid", chks);
			RequestDispatcher dispatcher = request.
					getRequestDispatcher("eshopper/loginhome.jsp?chkid="+chks);
			dispatcher.forward(request, response);
		}
	}
}
